const equal = (a, b) => {
    if (a == b)
        return true
    else 
        return false                                
}

const symbols_to_words = (array, symbol, prevsymbol, operation, counter = 0, word = '', result = []) => {

	if (counter >= array.length) {
		return result
	}

	if (operation(array[count], symbol)){
		word.push(symbol)
		result.push(word)
	}
	
	return symbols_to_words(array, symbol, symbol, operation, counter + 1, word, result)
}

let array = 'a aa aaa'

console.log(symbols_to_words(array, 'a', prevsymbol, equal))