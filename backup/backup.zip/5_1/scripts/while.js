
const equal = (a, b) => {
    if (a == b)
        return true
    else 
        return false                                
}

const foreach = (array, procedure, counter = 0, ...args) => {

	if (counter >= array.length) {
		return null
	}

	else {
		procedure(array[counter], ...args)
		return foreach(array, procedure, counter + 1, ...args)
		
	}
}



// const compare_next_symbol = (counter) => {
// 	if (sample == symbol){
// 		word.push(symbol)
// 		return compare_next_symbol(counter)
// 	}
// 	else {
// 		return word
// 	}
// }

// const compare_symbols = (sample, symbol) => {
// 	if (sample == symbol){
// 		word.push(symbol)
// 		compare_next_symbol(counter)			
// 	}

// }

const whiler = (condition, change, procedure, result, ...args) => {
	if (condition != true) {
		return result
	} else {
		procedure(...args)
		whiler(condition, change, procedure, result, args)
	}
}


const symbols_to_words_rec = (array, symbol) => {
	
	let result = []
	let counter = 0
	let word = []
	

		

	// const compare_symbols = (sample, counter, symbol) => {

	// 	if (array[counter] == symbol){
	// 		word = []
	// 		word.push(symbol)
	// 		return result.push(word)
	// 	} else return result
	// }

	const compare_symbols = (sample, symbol) => {
			console.log(counter)
			if (sample == symbol){
				if (array[counter] == symbol){
					
					word.push(symbol)
					
					result.push(word)	
					
				}
			}
				else {
					
					word = []
					
				}
			
		}



	//foreach(array, compare_symbols, counter, symbol)
	console.log(whiler(equal(array[counter], symbol) && counter < array.length, counter++, compare_symbols, result, array[counter], symbol))

	return result
	
}


let array = 'a aa aaaa aaa'
console.log(symbols_to_words_rec(array, "a"))

// foreach(array, equal, 0, "a")


// const symbols_to_words = (array, symbol, operation) => {
// 	let word = []
// 	let result = []
        
//     for(let i = 0; i < array.length; i++) {       
//         if(operation(array[i], symbol)){
           
//         	for (;operation(array[i], symbol) && i < array.length; i++){
//         		word.push(array[i])  
//         		//i++
//         	}
//         	result.push(word)
//         	word = []
//         }
//     }    
//     return result
// }

// let array = 'a aa aaaa aaa'


// console.log(symbols_to_words_rec(array, 'a', equal))