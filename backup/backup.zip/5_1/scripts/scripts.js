/*
	ИНТЕРПРЕТАТОР
*/

/*
 Сначала простая задача.
 Сначала сделаю просто перебор символов строки.

 

 По шагам
 
 1) Прочитать
 
 2) Распознать, это значит соотнести с чем то, уже известным, значит должна быть какая то
 	таблица, в которой хранится соотношение внешности и смысла символов.

 3) Построить структуру, уже смословую, например дерево, где узлы это операции, а листья - операнды

 4) Выполнить, запустить вычисление дерева со смысловой структурой

 Теперь надо сделать, чтобы он объединял символы в слова

 Теперь определить порядок операторов, в сложении и умножении он неважен, но в вычитании и делении важен
 
*/

const foreach = (array, procedure, count) => {

	if (count >= array.length) {
		return null
	}

	else {
		procedure(array[count])
		return foreach(array, procedure, count + 1)
	}
}

const map = (array, procedure, count = 0,  result = []) => {
	
	if (count >= array.length) {
		return result
	}
	else{
		result.push(procedure(array[count]))
		return map(array, procedure, count + 1, result)
	}
}

const equal = (a, b) => {
    if (a == b)
        return true
    else 
        return false                                
}

// function filter(array, operation, property, value) {
//     let a = [];
        
//     for(let i = 0; i < array.length; ++i) {       
//          if(operation(array[i][property], value)){
//            a.push(array[i]);  
//          }
//     }    
//     return a;
// }

const filter = (array, operation, property, value, count = 0, result = [] ) => {

	if (count >= array.length) {		
		return result
	}
	else {
			if (operation(array[count][property], value)){
           		result.push(array[count])
         	}
		
		return filter(array, operation, property, value, count + 1, result) 
	}
}

const find = (array, operation, property, value, count = 0, result = {} ) => {

	if (count >= array.length) {		
		return result
	}
	else {
			if (operation(array[count][property], value)){
           		result = array[count]
         	}
		
		return find(array, operation, property, value, count + 1, result) 
	}
}

const extract = (array, field, count = 0, result = []) => {

	if (count >= array.length) {		
		return result
	}
	else {
		result.push(array[count][field])
		return extract(array, field, count + 1, result)
	}
}

const symbols_to_words = (array, property, symbol, operation, field) => {
	let word = []
	let result = []
	        
    for(let i = 0; i < array.length; i++) {       
    	
    	
	        if(operation(array[i][property], symbol)){
	    		
	    		//Используется хак с &&, при котором второе выражение не вычисляется   		        	
				while (i < array.length && operation(array[i][property], symbol)){	        		
	        		word.push(array[i][field])  
	        		i++
	        	}
	        	result.push(word.join(''))
	        	word = []
	        }
    	
    }    
    return result
}

const recognize = function(symbol) {
		
	return find(symbols_table, equal, "symbol", symbol)
}


let symbols_table = [
	
	{
		symbol: ' ',
		meaning: 'space',
		type: 'separator',
		datatype: 'syntax'
	},
	{
		symbol: '+',
		meaning: function() {  
					let  result = 0
  					for (let i = 0; i < arguments.length; i++) {
  						
  						result += Number(arguments[i])
  					}
					return result
				},
		type: 'operation',
		datatype: 'expression'
	},
	{
		symbol: '*',
		meaning: function() {  
					let  result = 1
  					for (let i = 0; i < arguments.length; i++) {

  						result *= Number(arguments[i])
  					}
					return result
				},
		type: 'operation',
		datatype: 'expression'
	},	
	{
		symbol: '0',
		meaning: 0,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '1',
		meaning: 1,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '2',
		meaning: 2,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '3',
		meaning: 3,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '4',
		meaning: 4,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '5',
		meaning: 5,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '6',
		meaning: 6,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '7',
		meaning: 7,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '8',
		meaning: 8,
		type: 'operand',
		datatype: 'number'
	},
	{
		symbol: '9',
		meaning: 9,
		type: 'operand',
		datatype: 'number'
	},	

]





const expr = ` +  5  40 2 `

const meaning = map(expr, recognize, 0)

console.log("meaning\n", meaning)


const operation = find(meaning, equal, "type", "operation").meaning
const operation_description = find(meaning, equal, "type", "operation").symbol

console.log(`operation\n ${operation_description}\n`, operation)

//const operands = extract(filter(meaning, equal, "type", "operand"), "meaning")

//console.log("operands\n", operands)

let words = symbols_to_words(meaning, "datatype", "number", equal, "symbol")
console.log("words", words)


console.log("result", operation(...words))
