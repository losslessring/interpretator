
const equal = (a, b) => {
    if (a == b)
        return true
    else 
        return false                                
}


const foreach = (array, procedure, count) => {

	if (count >= array.length) {
		return null
	}

	else {
		procedure(array[count])
		return foreach(array, procedure, count + 1)
	}
}

const map = (array, procedure, count = 0,  result = []) => {
	
	if (count >= array.length) {
		return result
	}
	else{
		result.push(procedure(array[count]))
		return map(array, procedure, count + 1, result)
	}
}



const filter = (array, operation, value, count = 0, result = [] ) => {

	if (count >= array.length) {		
		return result
	}
	else {
			if (operation(array[count], value)){
           		result.push(array[count])
         	}
		
		return filter(array, operation, value, count + 1, result) 
	}
}

const symbols_compare = (symbol, operation) => {
	if (operation(array[i], symbol)){

	}
}

const symbols_to_words_rec = (array, symbol, operation) => {
	let word = []
	let result = []

	return filter(array, equal, 'a')
}




const symbols_to_words = (array, symbol, operation) => {
	let word = []
	let result = []
        
    for(let i = 0; i < array.length; i++) {       
        if(operation(array[i], symbol)){
           
        	for (;operation(array[i], symbol) && i < array.length; i++){
        		word.push(array[i])  
        		//i++
        	}
        	result.push(word)
        	word = []
        }
    }    
    return result
}

let array = 'a aa aaaa aaa'

console.log(symbols_to_words_rec(array, 'a', equal))