const equal = (a, b) => {
    if (a == b)
        return true
    else 
        return false                                
}




const symbols_to_words = (array, symbol, prevsymbol, operation, counter = 0, word = [], result = []) => {
	
	if (counter >= array.length) {
		return result
	}

	if (operation(array[counter], symbol)){
		word.push(symbol)
		result.push(word)
		return symbols_to_words(array, symbol, array[counter], operation, counter + 1, word, result)	

		// if (operation(array[counter], prevsymbol)){

		// 	word.push(symbol)

		// } else {
		// 	word = []
		// }		
	} else {
		
		return symbols_to_words(array, symbol, array[counter], operation, counter + 1, [], result)		
	}
	
}

let array = 'a aa aaaa'

console.log(symbols_to_words(array, 'a', null, equal))