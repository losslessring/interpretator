
/*
Здесь весь процесс понимания написанного

 По шагам
 
 1) Прочитать
 
 2) Распознать, это значит соотнести с чем то, уже известным, значит должна быть какая то
 	таблица, в которой хранится соотношение внешности и смысла символов.

 3) Построить структуру, уже смысловую, например дерево, где узлы это операции, а листья - операнды

 4) Выполнить, запустить вычисление дерева со смысловой структурой

 5) Вернуть результат - большой объект, запустил - забыл, в котором будет все интерпретированное содержимое
*/

const understand = (expression) => {
	const meaning = map(expression, recognize, 0)

	console.log("meaning\n", meaning)



	let operands = symbols_to_words(meaning, "datatype", "number", equal, "symbol")
	let operations = symbols_to_words(meaning, "datatype", "expression", equal, "symbol")

	const sorted_operands_operations = operations.concat(operands).sort(function (a, b) {
			  if (a.position > b.position) {
			    return 1
			  }
			  if (a.position < b.position) {
			    return -1
			  }
			  // a должно быть равным b
			  return 0
			})



	console.log(`sorted_operands_operations\n`, sorted_operands_operations)
	

	let result = {
		meaning,
		operations,
		words,
		computed
	}

	return result

}