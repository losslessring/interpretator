/*
	ИНТЕРПРЕТАТОР
*/

/*

*/

const expression = (a, i = 0) => {
	// let a = '+ 1 97'

	// let i = 0

	const evalc = () => {
		
		let x = ''
		
		while (a[i] == ' ') {
			i++
		}
		
		if (a[i] == '+'){
			i++
			return Number(evalc()) + Number(evalc())
		}

		while (((a[i]) >= '0')  && ((a[i]) <= '9')){

			x += a[i]
			i++
		}


		return x
	}

	console.log(evalc())

}

expression('+ 1 2')